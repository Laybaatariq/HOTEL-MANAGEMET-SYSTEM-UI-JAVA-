
package hotelmanagementsystem;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ConnectionToDB {

    
    public static void main(String[] args) throws SQLException{
        
        try{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String dburl="jdbc:sqlserver://DESKTOP-C7821AJ;databaseName=RMS;integratedSecurity=true";
        Connection con=DriverManager.getConnection(dburl);
        Statement stat=(Statement) con.createStatement();
       
  
         System.out.println("Connected to Microsoft Sql Server ");
        }
        catch(ClassNotFoundException ex)
        {
            System.out.println("oops, there's an error");
           
        }
        
    }
    
}
