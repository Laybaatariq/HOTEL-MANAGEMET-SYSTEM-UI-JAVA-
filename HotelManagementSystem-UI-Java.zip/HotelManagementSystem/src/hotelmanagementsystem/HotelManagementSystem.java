

package hotelmanagementsystem;

;

public class HotelManagementSystem {

    
    public static void main(String[] args) {
      
      
    
    }
}
